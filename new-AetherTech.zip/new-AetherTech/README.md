# AetherTech local dashboard

Run the local web server from this folder:

```powershell
python -m http.server 5173
```

Then open http://localhost:5173 in your browser.
