# Contributing

- Create branches as `feature/<name>`, `fix/<name>`, or `docs/<name>`.
- Use concise imperative commit messages, for example `feat: add memory recall endpoint`.
- Never commit `.env`, tokens, uploads, or generated build output.
- Run the relevant lint/build check before opening a pull request.
- Require one review before merging to `main`.
