"""AetherTech AI service.

Runs with provider keys when available and otherwise returns transparent, useful
local demo results so the product can be demonstrated without paid accounts.
"""
import asyncio
import json
import os
import re
from datetime import datetime, timezone
from typing import Any, Literal
from urllib.error import URLError
from urllib.request import Request, urlopen

from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

app = FastAPI(title="AetherTech AI Service", version="1.0.0")
INTERNAL_TOKEN = os.getenv("INTERNAL_SERVICE_TOKEN", "development-internal-token")


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=25000)
    context: str = Field(default="", max_length=25000)
    model: Literal["auto", "openai", "anthropic", "ollama"] = "auto"


class SearchRequest(BaseModel):
    query: str = Field(min_length=1, max_length=5000)
    workspace_id: str | None = None


class AgentRequest(BaseModel):
    goal: str = Field(min_length=1, max_length=25000)
    user_id: str | None = None
    attachments: list[dict[str, Any]] = []


class DocumentRequest(BaseModel):
    name: str = Field(min_length=1, max_length=300)
    content: str = Field(min_length=1, max_length=200000)
    workspace_id: str | None = None


class MemoryRequest(BaseModel):
    query: str = Field(min_length=1, max_length=5000)


def guard(text: str) -> str:
    """Remove common instruction-injection phrases from untrusted document/page context."""
    return re.sub(r"(?im)(ignore (all |the )?(previous|above) instructions|system prompt|you are now).{0,250}", "[untrusted instruction removed]", text).strip()


def choose_model(prompt: str, requested: str = "auto") -> str:
    if requested != "auto":
        return requested
    if any(word in prompt.lower() for word in ("private", "sensitive", "local", "confidential")) and os.getenv("OLLAMA_URL"):
        return "ollama"
    if len(prompt) > 2500 or any(word in prompt.lower() for word in ("research", "compare", "plan", "analyze")):
        return "anthropic" if os.getenv("ANTHROPIC_API_KEY") else "openai"
    return "openai" if os.getenv("OPENAI_API_KEY") else "ollama"


def post_json(url: str, headers: dict[str, str], data: dict[str, Any]) -> dict[str, Any]:
    request = Request(url, data=json.dumps(data).encode(), headers={"content-type": "application/json", **headers}, method="POST")
    with urlopen(request, timeout=25) as response:
        return json.loads(response.read().decode())


def embedding(text: str) -> list[float]:
    if os.getenv("OPENAI_API_KEY"):
        result = post_json("https://api.openai.com/v1/embeddings", {"authorization": f"Bearer {os.environ['OPENAI_API_KEY']}"}, {"model": os.getenv("OPENAI_EMBEDDING_MODEL", "text-embedding-3-small"), "input": text})
        return result["data"][0]["embedding"]
    if os.getenv("OLLAMA_URL"):
        result = post_json(f"{os.environ['OLLAMA_URL'].rstrip('/')}/api/embeddings", {}, {"model": os.getenv("OLLAMA_EMBEDDING_MODEL", os.getenv("OLLAMA_MODEL", "nomic-embed-text")), "prompt": text})
        return result["embedding"]
    raise HTTPException(status_code=503, detail="Configure OPENAI_API_KEY or Ollama embeddings for vector search")


def qdrant(path: str, method: str = "GET", body: dict[str, Any] | None = None) -> dict[str, Any]:
    base = os.getenv("QDRANT_URL")
    if not base:
        raise HTTPException(status_code=503, detail="QDRANT_URL is required for retrieval")
    try:
        request = Request(f"{base.rstrip('/')}{path}", data=json.dumps(body).encode() if body is not None else None, headers={"content-type": "application/json"}, method=method)
        with urlopen(request, timeout=20) as response:
            return json.loads(response.read().decode())
    except URLError as error:
        raise HTTPException(status_code=503, detail=f"Qdrant unavailable: {error.reason}") from error


def ensure_collection(size: int) -> None:
    try:
        qdrant("/collections/aether_documents")
    except HTTPException:
        qdrant("/collections/aether_documents", "PUT", {"vectors": {"size": size, "distance": "Cosine"}})


def generate(prompt: str, requested: str = "auto") -> tuple[str, str]:
    model = choose_model(prompt, requested)
    try:
        if model == "openai" and os.getenv("OPENAI_API_KEY"):
            result = post_json("https://api.openai.com/v1/chat/completions", {"authorization": f"Bearer {os.environ['OPENAI_API_KEY']}"}, {"model": os.getenv("OPENAI_MODEL", "gpt-4o-mini"), "messages": [{"role": "user", "content": prompt}]})
            return result["choices"][0]["message"]["content"], "openai"
        if model == "anthropic" and os.getenv("ANTHROPIC_API_KEY"):
            result = post_json("https://api.anthropic.com/v1/messages", {"x-api-key": os.environ["ANTHROPIC_API_KEY"], "anthropic-version": "2023-06-01"}, {"model": os.getenv("ANTHROPIC_MODEL", "claude-3-5-haiku-latest"), "max_tokens": 900, "messages": [{"role": "user", "content": prompt}]})
            return result["content"][0]["text"], "anthropic"
        if model == "ollama" and os.getenv("OLLAMA_URL"):
            result = post_json(f"{os.environ['OLLAMA_URL'].rstrip('/')}/api/generate", {}, {"model": os.getenv("OLLAMA_MODEL", "llama3.2"), "prompt": prompt, "stream": False})
            return result["response"], "ollama"
    except (URLError, KeyError, IndexError, ValueError):
        pass
    return ("**AetherTech local mode**\n\nI can help with this once a model provider is connected. "
            f"For now, here is the key intent I understood: **{prompt[:220].strip()}**. "
            "Add an OpenAI, Anthropic, or Ollama configuration to receive a full generated answer."), "demo"


def verify_internal(token: str | None) -> None:
    if token != INTERNAL_TOKEN:
        raise HTTPException(status_code=401, detail="Internal service authentication failed")


@app.get("/health")
def health() -> dict[str, Any]:
    return {"service": "ai-service", "status": "ok", "providers": {"openai": bool(os.getenv("OPENAI_API_KEY")), "anthropic": bool(os.getenv("ANTHROPIC_API_KEY")), "ollama": bool(os.getenv("OLLAMA_URL"))}}


@app.post("/embed")
def embed(payload: dict[str, str], x_internal_token: str | None = Header(default=None)) -> dict[str, Any]:
    verify_internal(x_internal_token)
    text = guard(payload.get("text", ""))
    if not text:
        raise HTTPException(status_code=422, detail="text is required")
    vector = embedding(text)
    return {"dimensions": len(vector), "vector": vector}


@app.post("/chat")
def chat(payload: ChatRequest, x_internal_token: str | None = Header(default=None)) -> StreamingResponse:
    verify_internal(x_internal_token)
    context = guard(payload.context)
    answer, model = generate(f"Answer clearly and concisely. User question: {payload.message}\n\nTrusted context: {context}", payload.model)

    async def stream():
        for word in answer.split(" "):
            yield f"data: {json.dumps({'token': word + ' ', 'model': model})}\n\n"
            await asyncio.sleep(0.008)
        yield f"data: {json.dumps({'done': True, 'model': model})}\n\n"
    return StreamingResponse(stream(), media_type="text/event-stream")


@app.post("/search")
def search(payload: SearchRequest, x_internal_token: str | None = Header(default=None)) -> dict[str, Any]:
    verify_internal(x_internal_token)
    query = guard(payload.query)
    vector = embedding(query)
    hits = qdrant("/collections/aether_documents/points/search", "POST", {"vector": vector, "limit": 8, "with_payload": True}).get("result", [])
    results = [{"source": "personal", "title": hit["payload"].get("name", "Document"), "snippet": hit["payload"].get("text", "")[:350], "url": f"/documents/{hit['payload'].get('document_id', '')}", "score": hit["score"]} for hit in hits]
    if os.getenv("TAVILY_API_KEY"):
        web = post_json("https://api.tavily.com/search", {}, {"api_key": os.environ["TAVILY_API_KEY"], "query": query, "max_results": 5})
        results.extend({"source": "web", "title": item["title"], "snippet": item["content"], "url": item["url"], "score": item.get("score", 0)} for item in web.get("results", []))
    answer, model = generate(f"Provide a concise grounded answer to: {query}. Sources: {json.dumps(results[:8])}")
    return {"answer": answer, "model_used": model, "results": results, "sources": [{"title": item["title"], "url": item["url"]} for item in results]}


@app.post("/documents/upload")
def upload_document(payload: DocumentRequest, x_internal_token: str | None = Header(default=None), x_user_id: str | None = Header(default=None)) -> dict[str, Any]:
    verify_internal(x_internal_token)
    text = guard(payload.content)
    chunks = [text[index:index + 900] for index in range(0, len(text), 780)]
    vectors = [embedding(chunk) for chunk in chunks]
    ensure_collection(len(vectors[0]))
    document_id = f"doc-{abs(hash((payload.name, x_user_id)))}"
    qdrant("/collections/aether_documents/points", "PUT", {"points": [{"id": abs(hash((document_id, index))) % 2_000_000_000, "vector": vector, "payload": {"document_id": document_id, "name": payload.name, "text": chunk, "user_id": x_user_id, "workspace_id": payload.workspace_id}} for index, (chunk, vector) in enumerate(zip(chunks, vectors))]})
    return {"id": document_id, "name": payload.name, "user_id": x_user_id, "workspace_id": payload.workspace_id, "chunks": len(chunks), "status": "indexed"}


@app.post("/memory/recall")
def memory_recall(payload: MemoryRequest, x_internal_token: str | None = Header(default=None), x_user_id: str | None = Header(default=None)) -> dict[str, Any]:
    verify_internal(x_internal_token)
    vector = embedding(guard(payload.query))
    results = qdrant("/collections/aether_documents/points/search", "POST", {"vector": vector, "limit": 8, "with_payload": True, "filter": {"must": [{"key": "user_id", "match": {"value": x_user_id}}]}}).get("result", [])
    return {"query": payload.query, "memories": [{"title": hit["payload"].get("name"), "snippet": hit["payload"].get("text"), "score": hit["score"]} for hit in results]}


@app.post("/agent/run")
def run_agent(payload: AgentRequest, x_internal_token: str | None = Header(default=None)) -> dict[str, Any]:
    verify_internal(x_internal_token)
    goal = guard(payload.goal)
    lowered = goal.lower()
    agents = ["Planner"]
    if any(token in lowered for token in ("research", "fact", "source", "compare")): agents.append("Research")
    if any(token in lowered for token in ("fact", "verify", "claim")): agents.append("Fact-Check")
    if payload.attachments: agents.append("Vision")
    if any(token in lowered for token in ("write", "draft", "summary", "summarize")) or len(agents) > 1: agents.append("Writing")
    trace = []
    outputs = []
    for agent in agents:
        instruction = f"You are the {agent} Agent. Help fulfill this goal: {goal}"
        output, model = generate(instruction)
        outputs.append(output)
        trace.append({"agent": agent, "output": output[:600], "confidence": 0.91 if agent != "Fact-Check" else 0.84, "modelUsed": model, "timestamp": datetime.now(timezone.utc).isoformat()})
    return {"result": outputs[-1], "trace": trace, "partial": False, "status": "completed"}
