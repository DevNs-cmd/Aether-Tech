const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:4000";

export type Session = { accessToken: string; refreshToken: string; user: { id: string; name: string; email: string; role: "admin" | "member" } };

export function getSession(): Session | null {
  if (typeof window === "undefined") return null;
  const value = window.localStorage.getItem("aether-session");
  return value ? JSON.parse(value) as Session : null;
}

export async function api<T>(path: string, options: RequestInit = {}): Promise<T> {
  const session = getSession();
  const response = await fetch(`${API_URL}${path}`, { ...options, headers: { "content-type": "application/json", ...(session ? { authorization: `Bearer ${session.accessToken}` } : {}), ...options.headers } });
  if (!response.ok) { const error = await response.json().catch(() => ({})); throw new Error(error.error ?? "AetherTech request failed"); }
  return response.status === 204 ? undefined as T : response.json() as Promise<T>;
}

export async function demoLogin(email: string, name: string): Promise<Session> {
  const session = await api<Session>("/auth/demo-login", { method: "POST", body: JSON.stringify({ email, name }) });
  window.localStorage.setItem("aether-session", JSON.stringify(session));
  return session;
}
