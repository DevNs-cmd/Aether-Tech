import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AetherTech",
  description: "AI-powered browser assistant"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
