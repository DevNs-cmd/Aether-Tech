"use client";

import { FormEvent, useEffect, useState } from "react";
import { demoLogin } from "../../lib/api";

export default function LoginPage() {
  const [email, setEmail] = useState("maya@aether.tech");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  useEffect(() => { const encoded = new URLSearchParams(window.location.search).get("session"); if (encoded) { try { window.localStorage.setItem("aether-session", atob(encoded.replace(/-/g, "+").replace(/_/g, "/"))); window.location.href = "/"; } catch { setError("Google sign-in response could not be read."); } } }, []);
  async function login(event: FormEvent) { event.preventDefault(); setLoading(true); setError(""); try { await demoLogin(email, email.split("@")[0].replace(/^./, (letter) => letter.toUpperCase())); window.location.href = "/"; } catch (reason) { setError(reason instanceof Error ? reason.message : "Unable to sign in"); } finally { setLoading(false); } }
  return <main className="login-page"><section className="login-card"><div className="login-brand"><span>✦</span> Aether<span>Tech</span></div><p className="eyebrow">WELCOME TO YOUR WORKSPACE</p><h1>Make every thought<br /><em>go further.</em></h1><p>Sign in to connect your research, notes, and AI team.</p><form onSubmit={login}><label>Email<input type="email" required value={email} onChange={(event) => setEmail(event.target.value)} /></label>{error && <small className="login-error">{error}</small>}<button className="primary" disabled={loading}>{loading ? "Signing in..." : "Continue with demo account ->"}</button></form><div className="login-divider"><span />or<span /></div><a className="google-login" href="http://localhost:4000/auth/google">G <span>Continue with Google</span></a><small>Google OAuth activates after you add Google credentials to `.env`.</small></section><div className="login-art"><div>✦</div><p>One place for your work.<br /><strong>Infinite room to think.</strong></p></div></main>;
}
