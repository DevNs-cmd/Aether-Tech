"use client";

import { FormEvent, useState } from "react";
import { api } from "../lib/api";

export function LiveSearchView({ query, setQuery, notify }: { query: string; onSearch: (event: FormEvent) => void; setQuery: (query: string) => void; notify: (message: string) => void }) {
  const [answer, setAnswer] = useState("");
  const [results, setResults] = useState<Array<{ source: string; title: string; snippet: string; url: string }>>([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  async function run(event: FormEvent) { event.preventDefault(); setLoading(true); setError(""); try { const data = await api<{ answer: string; results: Array<{ source: string; title: string; snippet: string; url: string }> }>("/api/ai/search", { method: "POST", body: JSON.stringify({ query }) }); setAnswer(data.answer); setResults(data.results ?? []); } catch (reason) { setError(reason instanceof Error ? reason.message : "Search failed"); } finally { setLoading(false); } }
  return <><div className="page-heading"><div><p className="eyebrow">AI SEARCH</p><h1>Find the signal.</h1><p>Answers grounded in your documents and live web results.</p></div><span className="model-pill"><i /> Aether routing</span></div><form className="search-bar" onSubmit={run}><span>Search</span><input value={query} onChange={(event) => setQuery(event.target.value)} /><button>{loading ? "Searching..." : "Search"}</button></form>{error && <p className="login-error">{error}. Sign in at /login and ensure configured services are running.</p>}{answer && <div className="answer-card"><div className="answer-top"><span className="mini-star">AI</span><strong>Aether synthesis</strong><button onClick={() => { navigator.clipboard.writeText(answer); notify("Answer copied to clipboard"); }}>Copy</button></div><p>{answer}</p></div>}<div className="result-grid">{results.map((result) => <article key={`${result.source}-${result.url}`}><p className={`result-label ${result.source === "web" ? "web" : ""}`}>{result.source === "web" ? "WEB SOURCE" : "YOUR DOCUMENT"}</p><h3>{result.title}</h3><p>{result.snippet}</p><a href={result.url} target="_blank">Open source -&gt;</a></article>)}</div></>;
}
