const API = "http://localhost:4000";

chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  chrome.contextMenus.create({ id: "aether-explain", title: "Explain with AetherTech", contexts: ["selection"] });
  chrome.contextMenus.create({ id: "aether-summarize", title: "Summarize selection", contexts: ["selection"] });
});

chrome.commands.onCommand.addListener(async (command) => {
  if (command === "open-command-bar") {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.id) chrome.tabs.sendMessage(tab.id, { type: "AETHER_COMMAND" });
  }
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab?.id || !info.selectionText) return;
  const goal = info.menuItemId === "aether-explain" ? `Explain this selected text simply: ${info.selectionText}` : `Summarize this selected text: ${info.selectionText}`;
  chrome.tabs.sendMessage(tab.id, { type: "AETHER_RESULT", text: "Opening AetherTech…" });
  await chrome.sidePanel.open({ tabId: tab.id });
  chrome.storage.local.set({ pendingPrompt: goal });
});

async function token() { return (await chrome.storage.local.get("accessToken")).accessToken; }
async function request(path, body) {
  const accessToken = await token();
  const response = await fetch(`${API}${path}`, { method: "POST", headers: { "content-type": "application/json", ...(accessToken ? { authorization: `Bearer ${accessToken}` } : {}) }, body: JSON.stringify(body) });
  if (!response.ok) throw new Error((await response.json()).error || "Request failed");
  return response;
}
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (message.type === "AETHER_SAVE_NOTE") request("/api/notes", { title: sender.tab?.title || "Saved highlight", content: message.text, sourceUrl: sender.tab?.url }).then(() => respond({ ok: true })).catch((error) => respond({ error: error.message }));
  if (message.type === "AETHER_PAGE_TEXT") respond({ ok: true });
  return true;
});
