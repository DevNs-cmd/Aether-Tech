function closeAetherBar() { document.querySelector("#aether-command-bar")?.remove(); }
function openAetherBar() {
  closeAetherBar(); const bar = document.createElement("div"); bar.id = "aether-command-bar";
  bar.innerHTML = `<div class="aether-bar"><span>✦</span><input autofocus placeholder="Ask Aether about this page…" /><kbd>ESC</kbd></div>`;
  document.documentElement.append(bar); const input = bar.querySelector("input"); input.focus();
  input.addEventListener("keydown", (event) => { if (event.key === "Escape") closeAetherBar(); if (event.key === "Enter" && input.value.trim()) { chrome.storage.local.set({ pendingPrompt: `${input.value}\n\nPage context:\n${document.body.innerText.slice(0, 12000)}` }); closeAetherBar(); } });
}
chrome.runtime.onMessage.addListener((message) => { if (message.type === "AETHER_COMMAND") openAetherBar(); });
document.addEventListener("mouseup", () => {
  const selection = window.getSelection()?.toString().trim(); document.querySelector("#aether-save")?.remove();
  if (!selection || selection.length < 8) return;
  const button = document.createElement("button"); button.id = "aether-save"; button.textContent = "✦ Save to Aether";
  button.style.cssText = `position:fixed;z-index:2147483647;left:${Math.min(window.innerWidth - 150, 20 + (window.getSelection()?.getRangeAt(0).getBoundingClientRect().left || 0))}px;top:${Math.min(window.innerHeight - 50, 20 + (window.getSelection()?.getRangeAt(0).getBoundingClientRect().bottom || 0))}px`;
  button.onclick = () => { chrome.runtime.sendMessage({ type: "AETHER_SAVE_NOTE", text: selection }); button.remove(); };
  document.documentElement.append(button);
});
