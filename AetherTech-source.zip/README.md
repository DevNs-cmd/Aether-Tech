# AetherTech

AI-powered browser assistant and productivity workspace. AetherTech connects browser context, personal documents, notes, tasks, long-term memory, and inspectable multi-agent workflows.

## What is included

- Next.js dashboard: login, AI search, notes, tasks, memory timeline, knowledge graph, agent traces, document library, and admin UI.
- Express gateway: demo/Google sign-in entry points, signed tokens, admin/member RBAC, audit logging, rate limits, CRUD APIs, workspaces, memory recall, and AI proxy routes.
- FastAPI AI service: OpenAI/Anthropic/Ollama model routing, SSE chat, document chunking, hybrid-search response shape, injection filtering, and Planner/Research/Fact-Check/Writing/Vision agent traces.
- Manifest V3 Chrome extension: side panel chat, page understanding, right-click explain/summarize, highlight-to-note, command bar, screenshot action, and settings.
- Docker Compose services for PostgreSQL, Redis, Qdrant, gateway, AI service, and dashboard.

## Run locally

1. Copy `.env.example` to `.env` and set `JWT_SECRET` plus `INTERNAL_SERVICE_TOKEN` to long random values.
2. For a local demo without Docker:

   ```powershell
   cd backend/api-gateway; npm install; npm run dev
   cd ../../backend/ai-service; python -m pip install -r requirements.txt; uvicorn main:app --reload --port 8000
   cd ../../web; npm install; npm run dev
   ```

3. Create the database tables with `cd backend/api-gateway; npx prisma migrate dev --name init`.
4. Visit `http://localhost:3000/login`, sign in with Google OAuth, and load the `extension` folder at `chrome://extensions` using **Load unpacked**.

Or run the services together with `docker compose up --build`.

## Provider configuration

All services are configured through environment variables. Add these values to enable live integrations:

- `OPENAI_API_KEY` and optionally `OPENAI_MODEL`
- `ANTHROPIC_API_KEY` and optionally `ANTHROPIC_MODEL`
- `OLLAMA_URL` and `OLLAMA_MODEL` for a local model
- `TAVILY_API_KEY` for live web search (the interface supplies demo citations until connected)
- `GOOGLE_CLIENT_ID` and `GOOGLE_CALLBACK_URL` for Google OAuth

## Architecture

```text
Chrome extension / Next.js dashboard
              |
       Express API gateway -- PostgreSQL / Redis
              |
       FastAPI AI service -- Qdrant -- OpenAI / Anthropic / Ollama
```

## Security and scope

Secrets belong only in `.env`; it is ignored by Git. AI inputs are size-limited and untrusted document/page context is filtered before reaching a provider. The gateway fails closed if PostgreSQL, Qdrant, authentication, embeddings, or configured providers are unavailable.

Phase 2 roadmap: own crawler/index, Chromium fork, Kubernetes/Kafka/Temporal, enterprise ERP/CRM/HRMS integrations, AR/VR/IoT/robotics, and autonomous cross-site browser automation.
