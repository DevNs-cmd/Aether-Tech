"""AetherTech AI service.

Runs with provider keys when available and otherwise returns transparent, useful
local demo results so the product can be demonstrated without paid accounts.
"""
import asyncio
import json
import os
import re
from datetime import datetime, timezone
from typing import Any, Literal

from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import StreamingResponse
import httpx
from pydantic import BaseModel, Field

app = FastAPI(title="AetherTech AI Service", version="1.0.0")
INTERNAL_TOKEN = os.getenv("INTERNAL_SERVICE_TOKEN", "development-internal-token")


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=25000)
    context: str = Field(default="", max_length=25000)
    model: Literal["auto", "openai", "anthropic", "ollama"] = "auto"


class SearchRequest(BaseModel):
    query: str = Field(min_length=1, max_length=5000)
    workspace_id: str | None = None


class AgentRequest(BaseModel):
    goal: str = Field(min_length=1, max_length=25000)
    user_id: str | None = None
    attachments: list[dict[str, Any]] = []


class DocumentRequest(BaseModel):
    name: str = Field(min_length=1, max_length=300)
    content: str = Field(min_length=1, max_length=200000)
    workspace_id: str | None = None


class MemoryRequest(BaseModel):
    query: str = Field(min_length=1, max_length=5000)


def guard(text: str) -> str:
    """Remove common instruction-injection phrases from untrusted document/page context."""
    return re.sub(r"(?im)(ignore (all |the )?(previous|above) instructions|system prompt|you are now).{0,250}", "[untrusted instruction removed]", text).strip()


def choose_model(prompt: str, requested: str = "auto") -> str:
    if requested != "auto":
        return requested
    if any(word in prompt.lower() for word in ("private", "sensitive", "local", "confidential")) and os.getenv("OLLAMA_URL"):
        return "ollama"
    if len(prompt) > 2500 or any(word in prompt.lower() for word in ("research", "compare", "plan", "analyze")):
        return "anthropic" if os.getenv("ANTHROPIC_API_KEY") else "openai"
    return "openai" if os.getenv("OPENAI_API_KEY") else "ollama"


async def post_json(url: str, headers: dict[str, str], data: dict[str, Any]) -> dict[str, Any]:
    async with httpx.AsyncClient(timeout=25.0) as client:
        response = await client.post(url, json=data, headers=headers)
        response.raise_for_status()
        return response.json()


async def embedding_batch(texts: list[str]) -> list[list[float]]:
    if not texts:
        return []
    if os.getenv("OPENAI_API_KEY"):
        result = await post_json(
            "https://api.openai.com/v1/embeddings",
            {"authorization": f"Bearer {os.environ['OPENAI_API_KEY']}"},
            {"model": os.getenv("OPENAI_EMBEDDING_MODEL", "text-embedding-3-small"), "input": texts}
        )
        data = sorted(result.get("data", []), key=lambda x: x.get("index", 0))
        return [item["embedding"] for item in data]
    if os.getenv("OLLAMA_URL"):
        result = await post_json(
            f"{os.environ['OLLAMA_URL'].rstrip('/')}/api/embed",
            {},
            {"model": os.getenv("OLLAMA_EMBEDDING_MODEL", os.getenv("OLLAMA_MODEL", "nomic-embed-text")), "input": texts}
        )
        return result["embeddings"]
    raise HTTPException(status_code=503, detail="Configure OPENAI_API_KEY or Ollama embeddings for vector search")


async def embedding(text: str) -> list[float]:
    embeddings = await embedding_batch([text])
    return embeddings[0]


async def qdrant(path: str, method: str = "GET", body: dict[str, Any] | None = None) -> dict[str, Any]:
    base = os.getenv("QDRANT_URL")
    if not base:
        raise HTTPException(status_code=503, detail="QDRANT_URL is required for retrieval")
    url = f"{base.rstrip('/')}{path}"
    headers = {"content-type": "application/json"}
    try:
        async with httpx.AsyncClient(timeout=20.0) as client:
            if method == "GET":
                response = await client.get(url, headers=headers)
            elif method == "PUT":
                response = await client.put(url, json=body, headers=headers)
            elif method == "POST":
                response = await client.post(url, json=body, headers=headers)
            else:
                response = await client.request(method, url, json=body, headers=headers)
            response.raise_for_status()
            return response.json()
    except httpx.HTTPStatusError as error:
        raise HTTPException(status_code=503, detail=f"Qdrant status error: {error.response.status_code}") from error
    except httpx.RequestError as error:
        raise HTTPException(status_code=503, detail=f"Qdrant unavailable: {error}") from error


async def ensure_collection(size: int) -> None:
    try:
        await qdrant("/collections/aether_documents")
    except HTTPException:
        await qdrant("/collections/aether_documents", "PUT", {"vectors": {"size": size, "distance": "Cosine"}})


async def generate(prompt: str, requested: str = "auto") -> tuple[str, str]:
    model = choose_model(prompt, requested)
    try:
        if model == "openai" and os.getenv("OPENAI_API_KEY"):
            result = await post_json("https://api.openai.com/v1/chat/completions", {"authorization": f"Bearer {os.environ['OPENAI_API_KEY']}"}, {"model": os.getenv("OPENAI_MODEL", "gpt-4o-mini"), "messages": [{"role": "user", "content": prompt}]})
            return result["choices"][0]["message"]["content"], "openai"
        if model == "anthropic" and os.getenv("ANTHROPIC_API_KEY"):
            result = await post_json("https://api.anthropic.com/v1/messages", {"x-api-key": os.environ["ANTHROPIC_API_KEY"], "anthropic-version": "2023-06-01"}, {"model": os.getenv("ANTHROPIC_MODEL", "claude-3-5-haiku-latest"), "max_tokens": 900, "messages": [{"role": "user", "content": prompt}]})
            return result["content"][0]["text"], "anthropic"
        if model == "ollama" and os.getenv("OLLAMA_URL"):
            result = await post_json(f"{os.environ['OLLAMA_URL'].rstrip('/')}/api/generate", {}, {"model": os.getenv("OLLAMA_MODEL", "llama3.2"), "prompt": prompt, "stream": False})
            return result["response"], "ollama"
    except Exception:
        pass
    return ("**AetherTech local mode**\n\nI can help with this once a model provider is connected. "
            f"For now, here is the key intent I understood: **{prompt[:220].strip()}**. "
            "Add an OpenAI, Anthropic, or Ollama configuration to receive a full generated answer."), "demo"


def verify_internal(token: str | None) -> None:
    if token != INTERNAL_TOKEN:
        raise HTTPException(status_code=401, detail="Internal service authentication failed")


@app.get("/health")
def health() -> dict[str, Any]:
    return {"service": "ai-service", "status": "ok", "providers": {"openai": bool(os.getenv("OPENAI_API_KEY")), "anthropic": bool(os.getenv("ANTHROPIC_API_KEY")), "ollama": bool(os.getenv("OLLAMA_URL"))}}


@app.post("/embed")
async def embed(payload: dict[str, str], x_internal_token: str | None = Header(default=None)) -> dict[str, Any]:
    verify_internal(x_internal_token)
    text = guard(payload.get("text", ""))
    if not text:
        raise HTTPException(status_code=422, detail="text is required")
    vector = await embedding(text)
    return {"dimensions": len(vector), "vector": vector}


@app.post("/chat")
async def chat(payload: ChatRequest, x_internal_token: str | None = Header(default=None)) -> StreamingResponse:
    verify_internal(x_internal_token)
    context = guard(payload.context)
    prompt = f"Answer clearly and concisely. User question: {payload.message}\n\nTrusted context: {context}"
    model = choose_model(prompt, payload.model)

    async def stream():
        try:
            if model == "openai" and os.getenv("OPENAI_API_KEY"):
                async with httpx.AsyncClient(timeout=60.0) as client:
                    async with client.stream(
                        "POST",
                        "https://api.openai.com/v1/chat/completions",
                        headers={"authorization": f"Bearer {os.environ['OPENAI_API_KEY']}", "content-type": "application/json"},
                        json={"model": os.getenv("OPENAI_MODEL", "gpt-4o-mini"), "messages": [{"role": "user", "content": prompt}], "stream": True}
                    ) as response:
                        response.raise_for_status()
                        async for line in response.aiter_lines():
                            if line.startswith("data: "):
                                data_str = line[6:].strip()
                                if data_str == "[DONE]":
                                    break
                                data_json = json.loads(data_str)
                                delta = data_json.get("choices", [{}])[0].get("delta", {})
                                if "content" in delta:
                                    yield f"data: {json.dumps({'token': delta['content'], 'model': 'openai'})}\n\n"
                yield f"data: {json.dumps({'done': True, 'model': 'openai'})}\n\n"
                return

            if model == "anthropic" and os.getenv("ANTHROPIC_API_KEY"):
                async with httpx.AsyncClient(timeout=60.0) as client:
                    async with client.stream(
                        "POST",
                        "https://api.anthropic.com/v1/messages",
                        headers={
                            "x-api-key": os.environ["ANTHROPIC_API_KEY"],
                            "anthropic-version": "2023-06-01",
                            "content-type": "application/json"
                        },
                        json={"model": os.getenv("ANTHROPIC_MODEL", "claude-3-5-haiku-latest"), "max_tokens": 900, "messages": [{"role": "user", "content": prompt}], "stream": True}
                    ) as response:
                        response.raise_for_status()
                        async for line in response.aiter_lines():
                            if line.startswith("data: "):
                                data_str = line[6:].strip()
                                data_json = json.loads(data_str)
                                event_type = data_json.get("type")
                                if event_type == "content_block_delta":
                                    text_delta = data_json.get("delta", {}).get("text", "")
                                    yield f"data: {json.dumps({'token': text_delta, 'model': 'anthropic'})}\n\n"
                yield f"data: {json.dumps({'done': True, 'model': 'anthropic'})}\n\n"
                return

            if model == "ollama" and os.getenv("OLLAMA_URL"):
                async with httpx.AsyncClient(timeout=60.0) as client:
                    async with client.stream(
                        "POST",
                        f"{os.environ['OLLAMA_URL'].rstrip('/')}/api/generate",
                        json={"model": os.getenv("OLLAMA_MODEL", "llama3.2"), "prompt": prompt, "stream": True}
                    ) as response:
                        response.raise_for_status()
                        async for line in response.aiter_lines():
                            if line.strip():
                                data_json = json.loads(line)
                                token = data_json.get("response", "")
                                yield f"data: {json.dumps({'token': token, 'model': 'ollama'})}\n\n"
                yield f"data: {json.dumps({'done': True, 'model': 'ollama'})}\n\n"
                return
        except Exception:
            pass

        answer = ("**AetherTech local mode**\n\nI can help with this once a model provider is connected. "
                  f"For now, here is the key intent I understood: **{prompt[:220].strip()}**. "
                  "Add an OpenAI, Anthropic, or Ollama configuration to receive a full generated answer.")
        for word in answer.split(" "):
            yield f"data: {json.dumps({'token': word + ' ', 'model': 'demo'})}\n\n"
            await asyncio.sleep(0.008)
        yield f"data: {json.dumps({'done': True, 'model': 'demo'})}\n\n"

    return StreamingResponse(stream(), media_type="text/event-stream")


@app.post("/search")
async def search(payload: SearchRequest, x_internal_token: str | None = Header(default=None)) -> dict[str, Any]:
    verify_internal(x_internal_token)
    query = guard(payload.query)
    vector = await embedding(query)
    hits = (await qdrant("/collections/aether_documents/points/search", "POST", {"vector": vector, "limit": 8, "with_payload": True})).get("result", [])
    results = [{"source": "personal", "title": hit["payload"].get("name", "Document"), "snippet": hit["payload"].get("text", "")[:350], "url": f"/documents/{hit['payload'].get('document_id', '')}", "score": hit["score"]} for hit in hits]
    if os.getenv("TAVILY_API_KEY"):
        try:
            web = await post_json("https://api.tavily.com/search", {}, {"api_key": os.environ["TAVILY_API_KEY"], "query": query, "max_results": 5})
        except Exception:
            web = {}
        results.extend({"source": "web", "title": item["title"], "snippet": item["content"], "url": item["url"], "score": item.get("score", 0)} for item in web.get("results", []))
    answer, model = await generate(f"Provide a concise grounded answer to: {query}. Sources: {json.dumps(results[:8])}")
    return {"answer": answer, "model_used": model, "results": results, "sources": [{"title": item["title"], "url": item["url"]} for item in results]}


@app.post("/documents/upload")
async def upload_document(payload: DocumentRequest, x_internal_token: str | None = Header(default=None), x_user_id: str | None = Header(default=None)) -> dict[str, Any]:
    verify_internal(x_internal_token)
    text = guard(payload.content)
    chunks = [text[index:index + 900] for index in range(0, len(text), 780)]
    vectors = await embedding_batch(chunks)
    await ensure_collection(len(vectors[0]))
    document_id = f"doc-{abs(hash((payload.name, x_user_id)))}"
    await qdrant("/collections/aether_documents/points", "PUT", {"points": [{"id": abs(hash((document_id, index))) % 2_000_000_000, "vector": vector, "payload": {"document_id": document_id, "name": payload.name, "text": chunk, "user_id": x_user_id, "workspace_id": payload.workspace_id}} for index, (chunk, vector) in enumerate(zip(chunks, vectors))]})
    return {"id": document_id, "name": payload.name, "user_id": x_user_id, "workspace_id": payload.workspace_id, "chunks": len(chunks), "status": "indexed"}


@app.post("/memory/recall")
async def memory_recall(payload: MemoryRequest, x_internal_token: str | None = Header(default=None), x_user_id: str | None = Header(default=None)) -> dict[str, Any]:
    verify_internal(x_internal_token)
    vector = await embedding(guard(payload.query))
    results = (await qdrant("/collections/aether_documents/points/search", "POST", {"vector": vector, "limit": 8, "with_payload": True, "filter": {"must": [{"key": "user_id", "match": {"value": x_user_id}}]}})).get("result", [])
    return {"query": payload.query, "memories": [{"title": hit["payload"].get("name"), "snippet": hit["payload"].get("text"), "score": hit["score"]} for hit in results]}


@app.post("/agent/run")
async def run_agent(payload: AgentRequest, x_internal_token: str | None = Header(default=None)) -> dict[str, Any]:
    verify_internal(x_internal_token)
    goal = guard(payload.goal)
    lowered = goal.lower()
    agents = ["Planner"]
    if any(token in lowered for token in ("research", "fact", "source", "compare")): agents.append("Research")
    if any(token in lowered for token in ("fact", "verify", "claim")): agents.append("Fact-Check")
    if payload.attachments: agents.append("Vision")
    if any(token in lowered for token in ("write", "draft", "summary", "summarize")) or len(agents) > 1: agents.append("Writing")
    trace = []
    outputs = []
    for agent in agents:
        instruction = f"You are the {agent} Agent. Help fulfill this goal: {goal}"
        output, model = await generate(instruction)
        outputs.append(output)
        trace.append({"agent": agent, "output": output[:600], "confidence": 0.91 if agent != "Fact-Check" else 0.84, "modelUsed": model, "timestamp": datetime.now(timezone.utc).isoformat()})
    return {"result": outputs[-1], "trace": trace, "partial": False, "status": "completed"}
